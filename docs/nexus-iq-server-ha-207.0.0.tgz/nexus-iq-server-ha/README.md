<!--

    Sonatype Nexus (TM) Open Source Version
    Copyright (c) 2008-present Sonatype, Inc.
    All rights reserved. Includes the third-party code listed at http://links.sonatype.com/products/nexus/oss/attributions.

    This program and the accompanying materials are made available under the terms of the Eclipse Public License Version 1.0,
    which accompanies this distribution and is available at http://www.eclipse.org/legal/epl-v10.html.

    Sonatype Nexus (TM) Professional Version is available from Sonatype, Inc. "Sonatype" and "Sonatype Nexus" are trademarks
    of Sonatype, Inc. Apache Maven is a trademark of the Apache Software Foundation. M2eclipse is a trademark of the
    Eclipse Foundation. All other trademarks are the property of their respective owners.

-->
# Sonatype IQ Server High Availability Helm Chart

This repository is intended to store a helm chart to create a cluster of Sonatype IQ Server nodes.

## General Requirements
- A copy of the helm chart
- A Sonatype IQ Server license that supports the High Availability (HA) feature
- [kubectl](https://kubernetes.io/docs/tasks/tools/#kubectl) (1.23+) to run commands against a Kubernetes cluster
- [helm](https://helm.sh/docs/helm/) (3.9.3+ or 4.x) to install or upgrade the helm chart
- A PostgreSQL (10.7 or newer) database or a PostgreSQL-compatible service
- A Kubernetes cluster to run the helm chart on
- A shared file system to share files between all Sonatype IQ Server pods in the cluster
- A load balancer to distribute requests between the Sonatype IQ Server pods

## Nice to have
- A [storage class](https://kubernetes.io/docs/concepts/storage/storage-classes/) for dynamic provisioning

## Running

1. Start your Kubernetes cluster if needed
2. Open a console/terminal
3. Switch to the correct context to use your cluster if needed (e.g. `kubectl config use-context my-context`)
4. Add the helm chart repository via
   `helm repo add sonatype https://sonatype.github.io/helm3-charts/`
5. Install the helm chart via
   `helm install --namespace <namespace> <name> --dependency-update <overrides> sonatype/nexus-iq-server-ha --version <version>`
where
   1. `<namespace>` can be an existing namespace for the helm chart (created prior via
      `kubectl create namespace <namespace>`, or to create automatically include the flag `--create-namespace`)
   2. `<name>` can be any name for the helm chart
   3. `<overrides>` is a set of overrides for values in the helm chart (see below)
   4. `<version>` is the version of the helm chart to use
6. Expose the ingress if needed, which uses port `80` for http and port `443` for https by default

## Overrides

### License (required)

A Sonatype IQ Server license that supports the HA feature must be installed either before the cluster starts or as it is
starting to allow multiple pods to start successfully.

The license file can either be passed directly
   ```
   --set-file iq_server.license=<license file>
   ```
where `<license file>` is the path to your Sonatype IQ Server product license file

or via an existing secret
   ```
   --set iq_server.licenseSecret=<license secret>
   ```

### Database (required)

An existing database can be configured as follows
   ```
   --set iq_server.database.hostname=<database hostname>
   --set iq_server.database.port=<database port>
   --set iq_server.database.name=<database name>
   --set iq_server.database.username=<database username>
   ```
the database password can either be passed directly
   ```
   --set iq_server.database.password=<database password>
   ```
or via an existing secret
   ```
   --set iq_server.database.passwordSecret=<database password secret>
   ```

### Shared File System (required)

By default, the helm chart will create both a [Persistent Volume (PV)](https://kubernetes.io/docs/concepts/storage/persistent-volumes/#persistent-volumes)
using the configured storage and a corresponding
[Persistent Volume Claim (PVC)](https://kubernetes.io/docs/concepts/storage/persistent-volumes/#persistentvolumeclaims).

However, there are various configuration options.
* If a PV is created, then it will match the configuration.
* If a PVC is created, then it will only bind to a PV that satisfies the configuration.

#### Size

The [capcity](https://kubernetes.io/docs/concepts/storage/persistent-volumes/#capacity) or size can be set via
   ```
   --set iq_server.persistence.size=<storage size, default "1Gi">
   ```

#### Access Mode(s)

The [access mode(s)](https://kubernetes.io/docs/concepts/storage/persistent-volumes/#access-modes) can be set via
   ```
   --set iq_server.persistence.accessModes[0]=<access mode, default "ReadWriteMany">
   ```
Note that this should correspond to the type of PV being used.

If you have multiple nodes in your Kubernetes cluster, and a Sonatype IQ Server pod is running on 2 or more of
them, then this must be set to `ReadWriteMany` and you must use a type of PV that supports it.

#### Storage Class Name

The [storage class](https://kubernetes.io/docs/concepts/storage/storage-classes/) name can be set via
   ```
   --set iq_server.persistence.storageClassName=<storage class name, default "">
   ```

#### Type

The [type](https://kubernetes.io/docs/concepts/storage/persistent-volumes/#types-of-persistent-volumes) can be
configured as follows.

Note a PV can only have one type, so if multiple are configured, then only one will be used. The priority for which type
will be selected if multiple are configured is shown below i.e. a type with a lower number in the below list will be
chosen above a type with a higher number.

1. **csi**
   ```
   --set iq_server.persistence.csi.driver=<csi driver name>
   --set iq_server.persistence.csi.fsType=<filesystem type>
   --set iq_server.persistence.csi.volumeHandle=<volume handle>
   --set iq_server.persistence.csi.volumeAttributes=<volume attributes>
   ```
2. **nfs**
   ```
   --set iq_server.persistence.nfs.server=<nfs server hostname>
   --set iq_server.persistence.nfs.path=<nfs server path, default "/">
   ```

#### Existing PV and PVC

If you have an existing PV and PVC you wish to use, then you only need to set the PVC via
   ```
   --set iq_server.persistence.existingPersistentVolumeClaimName=<existing persistent volume claim name>
   ```

#### Existing PV

If you have an existing PV you wish to use, then you can set the PV via
   ```
   --set iq_server.persistence.existingPersistentVolumeName=<existing persistent volume name>
   ```
However, you may need to configure the PVC that will be created to allow it to bind to the PV using the previously
mentioned configuration options.


### Load Balancer (required)

An [ingress](https://kubernetes.io/docs/concepts/services-networking/ingress/) can be enabled with a particular [class
name](https://kubernetes.io/docs/concepts/services-networking/ingress/#ingress-class) to use an existing load balancer
as follows
   ```
   --set ingress.enabled=<true|false, default false>
   --set ingress.ingressClassName=<ingress class name, default "nginx">
   --set ingress.pathType=<ingress path type, default "Prefix">
   --set ingress.hostApplicationPath=<application path, default iq_server.config.server.applicationContextPath>
   --set ingress.hostAdminPath=<admin path, default iq_server.config.server.adminContextPath>
   --set ingress.hostApplication=<application hostname>
   --set ingress.hostAdmin=<admin hostname>
   --set ingress.annotations=<ingress annotations>
   ```
Note that if you want both the application and admin endpoints to be accessible, then they will need to be set to have
either different hostnames via e.g.
   ```
   --set iq_server.config.server.hostApplication="app.domain"
   --set iq_server.config.server.hostAdmin="admin.domain"
   ```
or different paths via e.g.
   ```
   --set iq_server.config.server.applicationContextPath="/"
   --set iq_server.config.server.adminContextPath="/admin"
   ```

Note that if no hostnames are specified, then any web traffic to the IP address of your ingress controller can be
matched without a name based virtual host being required.

#### TLS

If your [ingress class](https://kubernetes.io/docs/concepts/services-networking/ingress/#ingress-class) supports 
specifying TLS options directly based on your [ingress controller](https://kubernetes.io/docs/concepts/services-networking/ingress-controllers/),
then you can specify them as follows.

A TLS certificate and private key can either be passed directly
   ```
   --set ingress.tls[0].certificate=<tls certificate file>
   --set ingress.tls[0].key=<tls private key file>
   ```
where `<tls certificate file>` is the path to your TLS certificate file and `<tls private key file>` is the path to your
TLS private key file, or via an existing secret
   ```
   --set ingress.tls[0].secretName=<tls secret name>
   ```
The TLS secret must contain keys named `tls.cert` for the TLS certificate and `tls.key` for the TLS private key.

Additionally multiple hosts can be specified as follows
   ```
   --set ingress.tls[0].hosts[0]=<tls hostname>
   ```

Alternatively some ingress classes may support specifying TLS options through annotations.

### Domain Name System (DNS) Records (optional)

DNS records can be automatically managed using [ExternalDNS](https://github.com/kubernetes-sigs/external-dns) based on
an ingress. This is included in the chart and can be enabled via
   ```
   --set externalDns.enabled=true
   ```
and configured via
   ```
   --set externalDns.args=<array of arguments>
   ```

### Sonatype IQ Server Configuration (optional)

The number of pods can be specified as follows
   ```
   --set iq_server.replicas=<number of pods, default 2>
   ```

The initial admin password can either be passed directly
   ```
   --set iq_server.initialAdminPassword=<initial admin password>
   ```
or via an existing secret
   ```
   --set iq_server.initialAdminPasswordSecret=<initial admin password secret>
   ```

If planning to use ssh for git operations, enable the following flag to generate a private/public key pair.
You can retrieve the public key from the pod at <clusterDirectory>/.ssh/id_rsa.pub.
   ```
   --set iq_server.useGitSsh=<true/false>
   ```

A `config.yml` file is required to run. This is generated using the `iq_server.config` value. Care should be taken if
updating this as many values within it are fine-tuned to allow the helm chart to function.

### Logging

Each Sonatype IQ Server pod outputs application logs to stdout via console appenders and to log files on the shared
persistent volume. The default log files under the cluster directory are:
* `<pod-name>-clm-server.log` - main server log
* `<pod-name>-request.log` - HTTP request log
* `<pod-name>-audit.log` - audit events
* `<pod-name>-policy-violation.log` - policy violation events
* `<pod-name>-stderr.log` - JVM-level errors that bypass the logging framework (normally empty)

Note that JVM stderr is redirected to `<pod-name>-stderr.log` on the shared PV rather than to the container's stderr
stream. This means `kubectl logs` and log collectors that read container stdout/stderr will capture application logs
but not JVM-level errors such as `OutOfMemoryError` or native crashes. To monitor for these, collect
`<pod-name>-stderr.log` from the shared PV.

By default, each pod writes its log files to `/sonatype-work/clm-cluster/log/` with the pod name prefixed to each
filename (e.g., `iq-server-deployment-abc123-clm-server.log`). `${HOSTNAME}` is a Kubernetes-provided environment
variable that resolves to the pod name. This means log files from all HA nodes are accessible on the shared PV, and
the IQ Server support zip can collect logs from every node in the cluster.

Log aggregation is **not bundled** with this chart. If you require centralized log forwarding, you are responsible for
integrating your preferred log aggregation solution. A validated Fluent Bit example is provided in the `examples/` directory.

Most log collectors work out of the box by collecting container stdout output without any chart configuration changes.
To also capture JVM stderr and log files from terminated pods, configure your collector to read from the shared PV's
`log/` directory.

To disable file logging and use only console output, override `iq_server.config` in a values file to remove all
`type: file` appenders, keeping only the `type: console` entries. See the default `iq_server.config` in
`values.yaml` for the full structure.

Note that disabling file appenders means the support zip will not include log files, and `<pod-name>-stderr.log` on
the shared PV will be the only file-based log available.

#### Aggregate log cleanup

A CronJob is included to clean up old log files from the shared PV under the `log/` subPath. This handles both
per-pod log files from terminated pods and any legacy aggregate logs from previous Fluentd-bundled versions. By
default, log files older than 50 days are deleted daily at 1 am. This can be customized as follows
   ```
   --set aggregateLogFileRetention.deleteCron=<Cron schedule expression, default "0 1 * * *">
   --set aggregateLogFileRetention.maxLastModifiedDays=<max last modified time in days, default 50>
   ```
Note that setting `aggregateLogFileRetention.maxLastModifiedDays` to 0 disables deletion.

### Image (optional)

By default, the
[latest publicly available Sonatype IQ Server docker image](https://hub.docker.com/r/sonatype/nexus-iq-server)
will be used.

The image registry, image, tag, and imagePullPolicy can be overridden using
   ```
   --set iq_server.imageRegistry=<image registry, default nil meaning use the Docker public registry>
   --set iq_server.image=<image, default "sonatype/nexus-iq-server">
   --set iq_server.tag=<tag, default most recent version of Sonatype IQ Server>
   --set iq_server.imagePullPolicy=<imagePullPolicy, default "IfNotPresent">
   ```

## Amazon Web Services (AWS)

### Satisfying General Requirements
- [Relational Database Service (RDS) for PostgreSQL](https://aws.amazon.com/rds/) for a PostgreSQL database
- [Elastic Kubernetes Service (EKS)](https://aws.amazon.com/eks/) for a cluster
- [Elastic File System (EFS)](https://aws.amazon.com/efs/) with mount targets for a shared file system
- [Application Load Balancer (ALB)](https://aws.amazon.com/elasticloadbalancing/application-load-balancer/) for a load
balancer

### Additional Requirements
- [Virtual Private Cloud](https://docs.aws.amazon.com/vpc/latest/userguide/what-is-amazon-vpc.html) for the AWS
resources to communicate with each other
- [Amazon EFS CSI driver](https://docs.aws.amazon.com/eks/latest/userguide/efs-csi.html) pre-installed and configured in
the cluster

### Nice to have
- [EFS Storage Class](https://raw.githubusercontent.com/kubernetes-sigs/aws-efs-csi-driver/master/examples/kubernetes/dynamic_provisioning/specs/storageclass.yaml)
pre-installed and configured in the cluster for [dynamic provisioning](https://kubernetes.io/docs/concepts/storage/dynamic-provisioning/)
- [AWS Load Balancer Controller add-on](https://docs.aws.amazon.com/eks/latest/userguide/aws-load-balancer-controller.html)
pre-installed and configured in the cluster to automatically provision an ALB based on an ingress
- [ExternalDNS](https://github.com/kubernetes-sigs/external-dns) pre-installed/enabled and configured in the cluster to
automatically provision DNS records for [AWS Route 53](https://aws.amazon.com/route53/) based on an ingress.
- [Kubernetes Secrets Store CSI Driver](https://docs.aws.amazon.com/secretsmanager/latest/userguide/integrating_csi_driver.html)
pre-installed and configured in the cluster to enable AWS Secrets Manager access i.e. via
   1. `helm repo add secrets-store-csi-driver https://kubernetes-sigs.github.io/secrets-store-csi-driver/charts`
   2. `helm repo update`
   3. `helm upgrade --install --namespace kube-system csi-secrets-store secrets-store-csi-driver/secrets-store-csi-driver --set grpcSupportedProviders="aws" --set syncSecret.enabled=true`
   4. `kubectl apply -f https://raw.githubusercontent.com/aws/secrets-store-csi-driver-provider-aws/main/deployment/aws-provider-installer.yaml`
- [`aws-vault`](https://github.com/99designs/aws-vault) [pre-installed and configured](https://github.com/99designs/aws-vault/blob/master/USAGE.md#config)
  to ease authentication, in which case prefix the aws/kubectl/helm commands below with `aws-vault exec <aws-profile> -- <command>`.

### EKS

An existing EKS cluster is required to run the helm chart on.

To lookup existing clusters, run `aws eks --region <aws_region> list-clusters`.

To import the context for a cluster into your kubeconfig file, run
`aws eks --region <aws_region> update-kubeconfig --name <cluster_name>`.

### EFS

An existing EFS drive with mount targets can be used for the PV.

The PV can be provisioned statically or dynamically.

In either case, a CSI volume should be configured with
   ```
   --set iq_server.persistence.csi.driver="efs.csi.aws.com"
   --set iq_server.persistence.csi.fsType=""
   ```

and the access modes should be set as follows
   ```
   --set iq_server.persistence.accessModes[0]="ReadWriteMany"
   ```

#### Static Provisioning

To statically provision the PV use the following

   ```
   --set iq_server.persistence.csi.volumeHandle=<EFS file system ID>[:<EFS file system path>]
   ```
where `<EFS file system ID>` is your EFS file system ID, which typically looks like e.g. "fs-0ac8d13f38bfc99df" and
`<EFS file system path>` is an optional path into the file system e.g. ":/".

#### Dynamic Provisioning

To dynamically provision the PV via an EFS storage class use the following
   ```
   --set iq_server.persistence.persistentVolumeName=""
   --set iq_server.persistence.storageClassName=<EFS storage class name>
   ```

### AWS Secrets

The [AWS Secrets Manager](https://aws.amazon.com/secrets-manager/) can be used to store AWS secrets, which can be used
to pass the following

The product license file
   ```
   --set secret.license.arn=<aws secret arn containing product license file binary content>
   ```

The database settings
   ```
   --set secret.rds.arn=<aws secret arn containing database connection properties>
   ```

By default the chart expects the JSON keys inside that secret to be named `host`, `port`, `name`, `username`, and
`password`. If your secret uses different key names, override them individually:
   ```
   --set secret.rds.keys.host=<key name for database hostname, default "host">
   --set secret.rds.keys.port=<key name for database port, default "port">
   --set secret.rds.keys.name=<key name for database name, default "name">
   --set secret.rds.keys.username=<key name for database username, default "username">
   --set secret.rds.keys.password=<key name for database password, default "password">
   ```

The initial admin password
   ```
   --set secret.license.arn=<aws secret arn containing the initial admin password in an initial_admin_password key>
   ```

### ALB

For an ALB load balancer to work you will need to change the Sonatype IQ Server [service type](https://kubernetes.io/docs/concepts/services-networking/service/#publishing-services-service-types)
from its default of `ClusterIP` to `NodePort` via the following
   ```
   --set iq_server.serviceType=NodePort
   ```

#### Static Provisioning

To use an existing ALB and target groups via the AWS Load Balancer Controller add-on use the following

For the application endpoints
   ```
   --set existingApplicationLoadBalancer.applicationTargetGroupARN=<application target group arn>
   ```
For the admin endpoints
   ```
   --set existingApplicationLoadBalancer.adminTargetGroupARN=<admin target group arn>
   ```
Each command will create a target group binding, which will automatically synchronize targets to the given target group
pointing to the application/admin Sonatype IQ Server service endpoints.

Note that with static provisioning, you do not need to enable an ingress.

#### Dynamic Provisioning

To dynamically provision an ALB via the AWS Load Balancer Controller add-on use the following
   ```
   --set ingress.enabled=true
   --set ingress.ingressClassName=alb
   ```
and ensure that the [appropriate annotations](https://kubernetes-sigs.github.io/aws-load-balancer-controller/latest/guide/ingress/annotations/)
are set e.g.
   ```
   --set ingress.annotations."alb\.ingress\.kubernetes\.io/scheme"="internet-facing"
   --set ingress.annotations."alb\.ingress\.kubernetes\.io/target-type"="ip"
   --set ingress.annotations."alb\.ingress\.kubernetes\.io/healthcheck-path"="/ping"
   --set ingress.annotations."alb\.ingress\.kubernetes\.io/certificate-arn"="arn:aws:acm:<region>:<aws_account_id>:certificate/<certificate_id>"
   --set ingress.annotations."alb\.ingress\.kubernetes\.io/ssl-policy"="ELBSecurityPolicy-FS-1-2-Res-2020-10"
   --set ingress.annotations."alb\.ingress\.kubernetes\.io/listen-ports"='\[\{\"HTTPS\":80\}\,\{\"HTTPS\":443\}\]'
   --set ingress.annotations."alb\.ingress\.kubernetes\.io/actions\.ssl-redirect"='\{\"Type\": \"redirect\"\,\"RedirectConfig\":\{\"Protocol\":\"HTTPS\"\,\"Port\":\"443\"\,\"StatusCode\":\"HTTP_301\"\}\}'
   --set ingress.annotations."alb\.ingress\.kubernetes\.io/actions\.response-404"='\{\"type\":\"fixed-response\"\,\"fixedResponseConfig\":\{\"contentType\":\"text/plain\"\,\"statusCode\":\"404\"\,\"messageBody\":\"404_Not_Found\"\}\}'
   --set ingress.annotations."alb\.ingress\.kubernetes\.io/actions\.redirect-domain"='\{\"Type\":\"redirect\"\,\"RedirectConfig\":\{\"Host\":\"domain\"\,\"Path\":\"/#\{path\}\"\,\"Port\":\"443\"\,\"Protocol\":\"HTTPS\"\,\"Query\":\"#\{query\}\"\,\"StatusCode\":\"HTTP_301\"\}\}'
   --set ingress.annotations."alb\.ingress\.kubernetes\.io/load-balancer-attributes"="idle_timeout.timeout_seconds=600"
   ```
Note that if the application and admin services are separated by path rather than hostname, then multiple healthchecks
will need to be configured. This can be achieved by adding the healthcheck annotations at the service level rather than
the ingress level e.g.
   ```
   --set iq_server.applicationServiceAnnotations."alb\.ingress\.kubernetes\.io/healthcheck-path"="/ping"
   --set iq_server.adminServiceAnnotations."alb\.ingress\.kubernetes\.io/healthcheck-path"="/admin/ping"
   ```

### EFS Storage Class

If you want to use dynamic provisioning, then an EFS storage class should be pre-installed and configured in the cluster
with the correct settings to allow read/write access to the Sonatype IQ Server pod users, which have UID 1000 and GID 1000
by default e.g.
   ```
   kind: StorageClass
   apiVersion: storage.k8s.io/v1
     metadata:
     name: efs-sc
   provisioner: efs.csi.aws.com
   parameters:
     provisioningMode: efs-ap
     fileSystemId: <EFS file system ID>
     directoryPerms: "777"
     gidRangeStart: "1000"
     gidRangeEnd: "1000"
     basePath: "/"
   ```

### Examples

Some example commands are shown below.

#### External Database, Static EFS, and Dynamic ALB
   ```
   helm install --namespace staging mycluster --dependency-update
   --set-file iq_server.license="license.lic"
   --set iq_server.database.hostname=myhost
   --set iq_server.database.port=5432
   --set iq_server.database.name=iq
   --set iq_server.database.username=postgres
   --set iq_server.database.password=admin123
   --set iq_server.config.server.adminContextPath="/admin"
   --set iq_server.persistence.accessModes[0]="ReadWriteMany"
   --set iq_server.persistence.csi.driver="efs.csi.aws.com"
   --set iq_server.persistence.csi.fsType=""
   --set iq_server.persistence.csi.volumeHandle="fs-0ac8d13f38bfc99df:/"
   --set iq_server.serviceType=NodePort
   --set ingress.enabled=true
   --set ingress.ingressClassName=alb
   --set ingress.annotations."alb\.ingress\.kubernetes\.io/scheme"="internet-facing"
   --set ingress.annotations."alb\.ingress\.kubernetes\.io/healthcheck-path"="/ping" 
   sonatype/nexus-iq-server-ha --version <version>
   ```

#### External Database, Dynamic EFS, Dynamic ALB, and Secrets
   ```
   helm install --namespace staging mycluster --dependency-update
   --set iq_server.serviceAccountName=<service account name, default "default">
   --set serviceAccount.create=true
   --set serviceAccount.annotations."eks\.amazonaws\.com/role-arn"="arn:aws:iam::<aws_account_id>:role/<role_name>"
   --set secret.arn="arn:aws:secretsmanager:<region>:<aws_account_id>:secret:<secret_name>"
   --set secret.license.arn="arn:aws:secretsmanager:<region>:<aws_account_id>:secret:<secret_name>"
   --set secret.rds.arn="arn:aws:secretsmanager:<region>:<aws_account_id>:secret:<rds_secret_name>"
   --set iq_server.config.server.adminContextPath="/admin"
   --set iq_server.persistence.accessModes[0]="ReadWriteMany"
   --set iq_server.persistence.persistentVolumeName=""
   --set iq_server.persistence.storageClassName="efs-storage-class-name"
   --set iq_server.persistence.csi.driver="efs.csi.aws.com"
   --set iq_server.persistence.csi.fsType=""
   --set iq_server.serviceType=NodePort
   --set ingress.enabled=true
   --set ingress.ingressClassName=alb
   --set ingress.annotations."alb\.ingress\.kubernetes\.io/scheme"="internet-facing"
   --set ingress.annotations."alb\.ingress\.kubernetes\.io/healthcheck-path"="/ping" 
   sonatype/nexus-iq-server-ha --version <version>
   ```

### Autoscaling (@since 166.0.0)

Sonatype IQ Server HA helm chart includes support for Kubernetes Horizontal Pod Autoscaling (HPA). With this enabled you can set the
cluster to automatically scale up/down based on cpu and/or memory utilization.

#### Pre-requisites for autoscaling
Horizontal Pod Autoscaler depends on [metrics-server](https://github.com/kubernetes-sigs/metrics-server) being 
installed and available in the cluster. Please refer to the metrics-server [requirements](https://github.com/kubernetes-sigs/metrics-server/#requirements) 
and [installation](https://github.com/kubernetes-sigs/metrics-server/#installation) instructions for setting it up    

#### Configuring IQ server autoscaling
(Note: When setting auto-scaling parameters please make sure to have sufficient hardware resources available in the
underlying nodes meet the max pod demands.)

HPA is disabled by default. If you want to enable it, you need to set the `hpa.enabled` parameter to `true`.

   ```
   --set hpa.enabled=true
   ```
Defined resources requests for all the containers in the IQ Server pod are required for HPA to be able to compute
metrics. As a result, if you are scaling based on CPU usage you need to specify CPU requests for the IQ server.

Please refer to the "Chart Configuration Options" table below for detailed parameters for adjusting HPA configuration
to match your needs.

#### Autoscaling examples

Some example commands are shown below.

   ```
   helm install --namespace staging mycluster --dependency-update
    ...
    --set hpa.enabled=true
    --set iq_server.resources.requests.cpu="500m"
    --set iq_server.resources.limits.cpu="1000m"
    ...
   sonatype/nexus-iq-server-ha --version <version>
   ```

## On-Premises

### Satisfying General Requirements
* Any PostgreSQL database, we recommend one [setup for HA](https://www.postgresql.org/docs/current/high-availability.html)
* Any Kubernetes cluster, we recommend a multi-node cluster [setup for HA](https://kubernetes.io/docs/setup/production-environment/)
* Any shared file system, we recommend a [Network File System (NFS)](https://en.wikipedia.org/wiki/Network_File_System)
* Any [ingress controller](https://kubernetes.io/docs/concepts/services-networking/ingress-controllers/) pre-installed
and configured in the cluster, we recommend the [ingress-nginx controller](https://github.com/kubernetes/ingress-nginx)

### Example

An example command is shown below.

#### External Database, NFS, and ingress-nginx
   ```
   helm install --namespace staging mycluster --dependency-update
   --set-file iq_server.license="license.lic"
   --set iq_server.database.hostname=myhost
   --set iq_server.database.port=5432
   --set iq_server.database.name=iq
   --set iq_server.database.username=postgres
   --set iq_server.database.password=admin123
   --set iq_server.config.server.adminContextPath="/admin"
   --set iq_server.persistence.accessModes[0]="ReadWriteMany"
   --set iq_server.persistence.nfs.server=10.109.77.85
   --set iq_server.persistence.nfs.path=/
   --set iq_server.serviceType=NodePort
   --set ingress.enabled=true
   --set ingress-nginx.enabled=true
   sonatype/nexus-iq-server-ha --version <version>
   ```
### Useful Example For Local Testing

An example command with a persistence host path set useful for testing is shown below.

#### External Database, HostPath, and ingress-nginx
```
helm upgrade --namespace iq-ha iq-cluster  \
  --set-file iq_server.license="license.lic"
  --set iq_server.database.hostname=myhost
  --set iq_server.database.port=5432
  --set iq_server.database.name=iq
  --set iq_server.database.username=postgres
  --set iq_server.database.password=admin123
  --set iq_server.persistence.hostPath.path="/mnt/iq-server"
  --set iq_server.persistence.hostPath.type="DirectoryOrCreate"
  --set iq_server.persistence.accessModes[0]="ReadWriteOnce"
  --set iq_server.serviceType=NodePort
  --set ingress.enabled=true
  --set ingress-nginx.enabled=true
  sonatype/nexus-iq-server-ha --version <version>
```

## Upgrading

To upgrade Sonatype IQ Server and ensure a successful data migration, the following steps are recommended:

1. **Scale your pods down to zero.** This will delete the existing pods.
2. **Backup the database.** See the [IQ server backup guidelines](https://links.sonatype.com/products/nxiq/doc/backup) for more details.
3. **Update the helm chart.** Typically, this will also update the Sonatype IQ Server version.
4. **Run your helm chart upgrade command.** The deleted pods will be re-created with the updates.

### To 202.0.0
In this version, the bundled Fluentd subchart has been removed. Log aggregation is now the responsibility of the
customer. Key changes:

- Removed the `fluentd` subchart dependency and all `fluentd.*` values
- Removed the `cloudwatch.*` values (previously used by the Fluentd aggregator)
- Removed the Fluentd sidecar container from the IQ Server deployment
- Removed the Fluentd aggregator StatefulSet
- Log file appenders now write to the shared cluster directory (`/sonatype-work/clm-cluster/log/`) with the pod
  name prefixed to each filename (e.g., `<pod-name>-clm-server.log`), so the support zip can collect logs from
  all HA nodes and the existing CronJob handles cleanup automatically

**Action required:** If you were relying on the bundled Fluentd for log aggregation or CloudWatch integration,
you will need to deploy your own log collection solution. See the updated "Logging" section for guidance.

**Action required:** Remove any `fluentd.*` or `cloudwatch.*` overrides from your Helm values, as these are no
longer recognized.

**Action required:** If you have customized `iq_server.config` log file paths, update them to write under the
cluster directory `log/` subdirectory (e.g., `/sonatype-work/clm-cluster/log/<name>-${HOSTNAME}.log`) to ensure
the support zip can collect logs from all nodes and the cleanup CronJob handles retention.

## Log Aggregation

As of version 202.0.0, the Helm chart no longer includes a bundled log aggregator. Customers are responsible for
deploying their own log aggregation solution. This section provides guidance on integrating external log aggregators.

### Log File Locations

IQ Server pods write logs to the shared cluster directory, which is accessible via the PVC:

| Log Type | File Pattern | Path |
|----------|-------------|------|
| Server | `<pod-name>-clm-server.log` | `/sonatype-work/clm-cluster/log/` |
| Request | `<pod-name>-request.log` | `/sonatype-work/clm-cluster/log/` |
| Audit | `<pod-name>-audit.log` | `/sonatype-work/clm-cluster/log/` |
| Policy Violation | `<pod-name>-policy-violation.log` | `/sonatype-work/clm-cluster/log/` |
| Stderr | `<pod-name>-stderr.log` | `/sonatype-work/clm-cluster/log/` |

### Log Format

Each log type uses a different default format — text for the server and request
logs, JSON Lines for the audit and policy-violation logs, and raw passthrough
for stderr. The samples below show what an aggregator tailing each file will
see under the chart's default configuration.

**Server log** (`*-clm-server.log`) — Logback text format, configured by the
server appender's `logFormat` in `iq_server.iqLogConfig.appenders`:

```
%d{'yyyy-MM-dd HH:mm:ss,SSSZ'} %level [%thread] %X{username} %logger - %msg%n
```

Sample line:

```
2026-06-08 00:14:26,433+0000 DEBUG [QuartzScheduler_ClusterManager]  com.sonatype.insight.brain.scheduler.QuartzJobStoreTX - ClusterManager: Check-in complete.
```

> Internal threads (scheduler, cluster manager) leave `%X{username}` empty,
> producing two consecutive spaces between `[thread]` and the logger name.
> Custom regex parsers must treat the user field as optional.

**Request log** (`*-request.log`) — Jetty access log format, configured by the
request appender's `logFormat`:

```
%clientHost %l %user [%date] "%requestURL" %statusCode %bytesSent %elapsedTime "%header{User-Agent}"
```

Sample line:

```
[0:0:0:0:0:0:0:1] - - [08/Jun/2026:00:14:39 +0000] "HEAD /healthcheck/threadDeadlock HTTP/1.1" 204 0 0 "curl/7.76.1"
```

**Audit log** (`*-audit.log`) — one JSON record per line. The schema is fixed
by the `com.sonatype.insight.audit` appender and is not configurable via
`logFormat`. The `timestamp` field is the time key.

Sample line:

```json
{"timestamp":"2026-06-08T14:02:32.659Z","requestMethod":"GET","requestUri":"/rest/user/session","remoteIpAddress":"127.0.0.1","username":"*UNKNOWN","domain":"authentication","type":"failure","error":"bad-session"}
```

**Policy-violation log** (`*-policy-violation.log`) — one JSON record per
violation. The schema is fixed by the `com.sonatype.insight.policy.violation`
appender; see
[help.sonatype.com/en/policy-violation-log.html](https://help.sonatype.com/en/policy-violation-log.html)
for the full field reference. The `eventTimestamp` field is the time key
(not `timestamp`).

> The policy-violation log is event-driven: a record is only written when a
> policy evaluation finds a violation. On a fresh deployment the file may
> not exist until the first evaluation runs — this is expected.

Sample line:

```json
{"eventType":"create","eventTimestamp":"2026-06-08T14:22:40.022Z","policyName":"Security-Critical","policyThreatLevel":10,"policyConditionTriggers":[{"reason":"Found security vulnerability CVE-2023-20873 with severity >= 9 (severity = 9.8)"}],"applicationPublicId":"sandbox-application","componentIdentifier":{"format":"maven","coordinates":{"artifactId":"spring-boot-actuator-autoconfigure","groupId":"org.springframework.boot","version":"2.4.3"}}}
```

**Stderr** (`*-stderr.log`) — raw JVM stderr passthrough. No fixed schema;
content is whatever the JVM writes to standard error (deprecation warnings,
JVM startup messages, uncaught exception stack traces).

Sample lines:

```
WARNING: A terminally deprecated method in sun.misc.Unsafe has been called
WARNING: sun.misc.Unsafe::objectFieldOffset has been called by com.thoughtworks.xstream.converters.reflection.SunUnsafeReflectionProvider (file:/opt/sonatype/nexus-iq-server/jars/insight-brain-service-1.204.0-01-server.jar)
```

### Integrating External Log Aggregators

The Helm chart supports a "bring your own aggregator" model. To integrate your log aggregator:

1. **Deploy your log aggregator** as a separate Kubernetes resource
2. **Mount the existing PVC** (`iq-server-pvc` by default) to access log files
3. **Configure your log aggregator** to tail the log files from `/sonatype-work/clm-cluster/log/`
4. **Forward logs** to your desired destination

### Example: Fluent Bit Integration

A working Fluent Bit example is provided in the `examples/fluent-bit/` directory of this repository. It runs as a single-replica `Deployment` (not a DaemonSet) — the IQ Server logs live on a shared RWX PVC, so one reader is what's needed; running per-node would duplicate every record N times.

**Prerequisites:**
- The example assumes your namespace is `iq-ha` (the YAML default). If using a different namespace, see the customization steps below.
- The example assumes your PVC is named `iq-server-pvc` (the chart default).

**Quick Deploy:**

```bash
# Deploy Fluent Bit with file output (local aggregation)
# These files create resources in the 'iq-ha' namespace by default
kubectl apply -f examples/fluent-bit/fluent-bit-configmap.yaml
kubectl apply -f examples/fluent-bit/fluent-bit-deployment.yaml
```

**To use a different namespace:**

```bash
# Download and modify
mkdir -p my-fluent-bit
cp examples/fluent-bit/*.yaml my-fluent-bit/
sed -i 's/namespace: iq-ha/namespace: your-namespace/g' my-fluent-bit/*.yaml
kubectl apply -f my-fluent-bit/

# Edit files with any custom changes before applying
sed 's/namespace: iq-ha/namespace: your-namespace/g' examples/fluent-bit/fluent-bit-configmap.yaml | kubectl apply -f -
sed 's/namespace: iq-ha/namespace: your-namespace/g' examples/fluent-bit/fluent-bit-deployment.yaml | kubectl apply -f -


```

**To use a different PVC name** (if you customized `iq_server.persistence.persistentVolumeClaimName`):

```bash
# Update the claimName in the Deployment
sed -i 's/claimName: iq-server-pvc/claimName: your-pvc-name/g' my-fluent-bit/fluent-bit-deployment.yaml
kubectl apply -f my-fluent-bit/
```

See the [examples/fluent-bit/README.md](../examples/fluent-bit/README.md) for complete documentation including verification steps and customization options. The example ConfigMap uses file output to write aggregated logs back to the shared PVC. To forward logs to external systems, modify the `[OUTPUT]` sections in the ConfigMap.

### Example: Datadog Integration

A second example in `examples/datadog/` shows the same Fluent Bit pattern with an additional Datadog HTTP-intake output (one `dd_source` per log type). It writes the same `*.aggregated.log` files to the PVC and ships records to Datadog over HTTPS. See [examples/datadog/README.md](../examples/datadog/README.md) for setup (API key secret, region selection) and verification steps.

### PVC Requirements for Log Aggregation

- **Access Mode**: `ReadWriteMany` (RWX) is required for multiple pods to share the volume
- **PVC Name**: `iq-server-pvc` (default, configurable via `iq_server.persistence.persistentVolumeClaimName`)
- **Mount Path in Aggregator**: Mount to any path and configure your aggregator to read from `<mount>/log/`

### Support Zip Integration

Logs written to the cluster directory are automatically included in support zips under the `cluster_log` directory.
This ensures that support can access aggregated logs from all HA nodes.

## Chart Configuration Options
| Parameter                                                          | Description                                                                                          | Default                    |
|--------------------------------------------------------------------|------------------------------------------------------------------------------------------------------|----------------------------|
| `iq_server.imageRegistry`                                          | Container image registry, if not specified the Docker public registry will be used                   | `nil`                      |
| `iq_server.image`                                                  | Sonatype IQ Server docker image                                                                      | `sonatype/nexus-iq-server` |
| `iq_server.imagePullPolicy`                                        | Sonatype IQ Server image pull policy                                                                 | `IfNotPresent`             |
| `iq_server.tag`                                                    | Sonatype IQ Server image tag                                                                         | See `values.yaml`          |
| `iq_server.imagePullSecret`                                        | Image pull secret name                                                                               | `""`                       |
| `iq_server.command`                                                | Container command override                                                                           | `[]`                       |
| `iq_server.args`                                                   | Container args override                                                                              | `[]`                       |
| `iq_server.resources.requests.cpu`                                 | Sonatype IQ Server request for CPU resources in CPU units                                            | `nil`                      |
| `iq_server.resources.requests.memory`                              | Sonatype IQ Server request for memory resources in bytes                                             | `nil`                      |
| `iq_server.resources.limits.cpu`                                   | Sonatype IQ Server limit for CPU resources in CPU units                                              | `nil`                      |
| `iq_server.resources.limits.memory`                                | Sonatype IQ Server limit for memory resources in bytes                                               | `nil`                      |
| `iq_server.javaOpts`                                               | Value for the JAVA_OPTS environment variable to pass custom settings to the JVM                      | `nil`                      |
| `iq_server.license`                                                | Path to your Sonatype IQ Server product license file                                                 | `nil`                      |
| `iq_server.licenseSecret`                                          | The name of the license secret                                                                       | `nil`                      |
| `iq_server.serviceType`                                            | Sonatype IQ Server service type                                                                      | `ClusterIP`                |
| `iq_server.database.hostname`                                      | Database hostname                                                                                    | `nil`                      |
| `iq_server.database.port`                                          | Database port                                                                                        | `5432`                     |
| `iq_server.database.name`                                          | Database name                                                                                        | `nil`                      |
| `iq_server.database.username`                                      | Database username                                                                                    | `postgres`                 |
| `iq_server.database.password`                                      | Database password                                                                                    | `nil`                      |
| `iq_server.database.passwordSecret`                                | Database password secret                                                                             | `nil`                      |
| `iq_server.persistence.existingPersistentVolumeClaimName`          | Existing persistent volume claim name                                                                | `nil`                      |
| `iq_server.persistence.existingPersistentVolumeName`               | Existing persistent volume name                                                                      | `nil`                      |
| `iq_server.persistence.persistentVolumeName`                       | Persistent volume name                                                                               | `iq-server-pv`             |
| `iq_server.persistence.persistentVolumeClaimName`                  | Persistent volume claim name                                                                         | `iq-server-pvc`            |
| `iq_server.persistence.persistentVolumeRetainPolicy`               | Persistent volume retain policy                                                                      | `keep`                     |
| `iq_server.persistence.persistentVolumeClaimRetainPolicy`          | Persistent volume claim retain policy                                                                | `keep`                     |
| `iq_server.persistence.size`                                       | Storage capacity for PV/PVC to provision/request                                                     | `1Gi`                      |
| `iq_server.persistence.storageClassName`                           | Reference an existing StorageClass; takes precedence over `storageClass.create`                       | `""`                       |
| `iq_server.persistence.storageClass.create`                        | Whether to create a StorageClass resource                                                            | `false`                    |
| `iq_server.persistence.storageClass.name`                          | StorageClass name (defaults to `<release>-storageclass`)                                             | `nil`                      |
| `iq_server.persistence.storageClass.annotations`                   | Additional StorageClass annotations                                                                  | `{}`                       |
| `iq_server.persistence.storageClass.labels`                        | Additional StorageClass labels                                                                       | `{}`                       |
| `iq_server.persistence.storageClass.provisioner`                   | CSI driver provisioner (required when `storageClass.create` is true)                                 | `nil`                      |
| `iq_server.persistence.storageClass.reclaimPolicy`                 | Reclaim policy (`Retain` or `Delete`)                                                                | `Retain`                   |
| `iq_server.persistence.storageClass.volumeBindingMode`             | Volume binding mode (`Immediate` or `WaitForFirstConsumer`)                                          | `Immediate`                |
| `iq_server.persistence.storageClass.allowVolumeExpansion`          | Allow volume expansion                                                                               | `true`                     |
| `iq_server.persistence.storageClass.mountOptions`                  | Mount options                                                                                        | `[]`                       |
| `iq_server.persistence.storageClass.parameters`                    | Parameters to pass to the provisioner                                                                | `{}`                       |
| `iq_server.persistence.accessModes[0]`                             | Access mode for the PV/PVC                                                                           | `ReadWriteOnce`            |
| `iq_server.persistence.csi.driver`                                 | CSI driver name                                                                                      | `nil`                      |
| `iq_server.persistence.csi.fsType`                                 | File system type                                                                                     | `nil`                      |
| `iq_server.persistence.csi.volumeHandle`                           | Volume handle                                                                                        | `nil`                      |
| `iq_server.persistence.nfs.server`                                 | NFS server hostname                                                                                  | `nil`                      |
| `iq_server.persistence.nfs.path`                                   | NFS server path                                                                                      | `/`                        |
| `iq_server.podAnnotations`                                         | Annotations for the Sonatype IQ Server pods                                                          | `nil`                      |
| `iq_server.serviceAccountName`                                     | Sonatype IQ Server service account name                                                              | `default`                  |
| `iq_server.serviceType`                                            | Sonatype IQ Server service type                                                                      | `ClusterIP`                |
| `iq_server.applicationServiceAnnotations`                          | Annotations for the Sonatype IQ Server application service                                           | `nil`                      |
| `iq_server.adminServiceAnnotations`                                | Annotations for the Sonatype IQ Server admin service                                                 | `nil`                      |
| `iq_server.replicas`                                               | Number of replicas                                                                                   | `2`                        |
| `iq_server.initialAdminPassword`                                   | Initial admin password                                                                               | `admin123`                 |
| `iq_server.initialAdminPasswordSecret`                             | Initial admin password secret                                                                        | `nil`                      |
| `iq_server.startupProbe.initialDelaySeconds`                       | Initial delay seconds for startup probe                                                              | `30`                       |
| `iq_server.startupProbe.periodSeconds`                             | Period seconds for startup probe                                                                     | `10`                       |
| `iq_server.startupProbe.timeoutSeconds`                            | Timeout seconds for startup probe                                                                    | `2`                        |
| `iq_server.startupProbe.failureThreshold`                          | Failure threshold for startup probe                                                                  | `180`                      |
| `iq_server.readinessProbe.initialDelaySeconds`                     | Initial delay seconds for readiness probe                                                            | `45`                       |
| `iq_server.readinessProbe.periodSeconds`                           | Period seconds for readiness probe                                                                   | `15`                       |
| `iq_server.readinessProbe.timeoutSeconds`                          | Timeout seconds for readiness probe                                                                  | `5`                        |
| `iq_server.readinessProbe.failureThreshold`                        | Failure threshold for readiness probe                                                                | `4`                        |
| `iq_server.livenessProbe.initialDelaySeconds`                      | Initial delay seconds for liveness probe                                                             | `180`                      |
| `iq_server.livenessProbe.periodSeconds`                            | Period seconds for liveness probe                                                                    | `20`                       |
| `iq_server.livenessProbe.timeoutSeconds`                           | Timeout seconds for liveness probe                                                                   | `3`                        |
| `iq_server.livenessProbe.failureThreshold`                         | Failure threshold for liveness probe                                                                 | `3`                        |
| `iq_server.config`                                                 | A YAML block which will be used as a configuration block for IQ Server                               | See `values.yaml`          |
| `iq_server.useGitSsh`                                              | Use SSH to execute git operations for SCM integrations                                               | `false`                    |
| `iq_server.sshPrivateKey`                                          | SSH private key file to store on the nodes for ssh git operations                                    | `nil`                      |
| `iq_server.sshPrivateKeySecret`                                    | SSH private key stored in k8s secret to be used for ssh git operations                               | `nil`                      |
| `iq_server.sshKnownHosts`                                          | SSH known hosts file to store on the nodes for ssh git operations                                    | `nil`                      |
| `iq_server.sshKnownHostsSecret`                                    | SSH known hosts stored in k8s secret to be used for ssh git operations                               | `nil`                      |
| `iq_server.pvOwnershipOverride`                                    | Specify a custom 'chown' command to modify ownership of directories                                  | See `values.yaml`          |
| `iq_server.pvOwnershipOverrideResources.resources.requests.cpu`    | Persistence ownership initContainer request for CPU resources in CPU units                           | `nil`                      |
| `iq_server.pvOwnershipOverrideResources.resources.requests.memory` | Persistence ownership initContainer request for memory resources in bytes                            | `nil`                      |
| `iq_server.pvOwnershipOverrideResources.resources.limits.cpu`      | Persistence ownership initContainer limit for CPU resources in CPU units                             | `nil`                      |
| `iq_server.pvOwnershipOverrideResources.resources.limits.memory`   | Persistence ownership initContainer limit for memory resources in bytes                              | `nil`                      |
| `iq_server.securityContext`                                        | Security-related settings for the pod                                                                | `nil`                      |
| `iq_server.nodeSelector`                                           | Node labels for pod assignment                                                                       | `{}`                       |
| `iq_server.tolerations`                                            | Tolerations for pod assignment                                                                       | `[]`                       |
| `iq_server.affinity`                                               | Affinity rules for pod assignment                                                                    | `{}`                       |
| `iq_server_jobs.migrationJobAnnotations`                           | Sonatype IQ DB Migration job Annotations                                                             | `nil`                      |
| `iq_server_jobs.migrationJobSpec`                                 | Top-level spec fields merged into the migrate-db job; set a key to `null` to omit it                 | `{ttlSecondsAfterFinished: 0}` |
| `iq_server_jobs.gitSshJobAnnotations`                             | git-ssh job Annotations (rendered only when `iq_server.useGitSsh` is true)                           | `nil`                      |
| `iq_server_jobs.gitSshJobSpec`                                    | Top-level spec fields merged into the git-ssh job; set a key to `null` to omit it                    | `{ttlSecondsAfterFinished: 0}` |
| `iq_server_jobs.env`                                               | Sonatype IQ DB Migration job environment variables                                                   | `nil`                      |
| `iq_server_jobs.resources.requests.cpu`                            | Sonatype IQ DB Migration job request for CPU resources in CPU units                                  | `nil`                      |
| `iq_server_jobs.resources.requests.memory`                         | Sonatype IQ DB Migration job request for memory resources in bytes                                   | `nil`                      |
| `iq_server_jobs.resources.limits.cpu`                              | Sonatype IQ DB Migration job limit for CPU resources in CPU units                                    | `nil`                      |
| `iq_server_jobs.resources.limits.memory`                           | Sonatype IQ DB Migration job limit for memory resources in bytes                                     | `nil`                      |
| `iq_server_jobs.nodeSelector`                                      | Node labels for job pod assignment                                                                   | `{}`                       |
| `iq_server_jobs.tolerations`                                       | Tolerations for job pod assignment                                                                   | `[]`                       |
| `iq_server_jobs.affinity`                                          | Affinity rules for job pod assignment                                                                | `{}`                       |
| `ingress.enabled`                                                  | Enable ingress                                                                                       | `false`                    |
| `ingress.className`                                                | Ingress class name                                                                                   | `nginx`                    |
| `ingress.pathType`                                                 | Ingress path type                                                                                    | `Prefix`                   |
| `ingress.annotations`                                              | Ingress annotations                                                                                  | `nil`                      |
| `ingress.hostApplication`                                          | Ingress host for application                                                                         | `nil`                      |
| `ingress.hostApplicationPath`                                      | Ingress path for application                                                                         | `nil`                      |
| `ingress.hostAdmin`                                                | Ingress host for admin application                                                                   | `nil`                      |
| `ingress.hostAdminPath`                                            | Ingress path for admin application                                                                   | `nil`                      |
| `ingress.tls`                                                      | Ingress TLS configuration                                                                            | `nil`                      |
| `ingress-nginx.enable`                                             | Enable ingress-nginx                                                                                 | `false`                    |
| `ingress-nginx.controller`                                         | Ingress controller configuration for Nginx                                                           | See `values.yaml`          |
| `externalDns.enabled`                                              | Enable external-dns                                                                                  | `false`                    |
| `externalDns.args`                                                 | Array of arguments to pass to the external-dns container                                             | See `values.yaml`          |
| `serviceAccount.create`                                            | Create service account                                                                               | `false`                    |
| `serviceAccount.labels`                                            | Service account labels                                                                               | `nil`                      |
| `serviceAccount.annotations`                                       | Service account annotations                                                                          | `nil`                      |
| `serviceAccount.autoMountServiceAccountToken`                      | Auto mount service account token                                                                     | `false`                    |
| `secret.arn`                                                       | AWS secret arn containing initial admin password in a initial_admin_password key                     | `nil`                      |
| `secret.license.arn`                                               | AWS secret arn containing the binary content of your Sonatype IQ Server license                      | `nil`                      |
| `secret.rds.arn`                                                   | AWS secret arn containing database connection properties                                             | `nil`                      |
| `secret.rds.keys.host`                                             | JSON key name in the RDS secret for the database hostname                                            | `host`                     |
| `secret.rds.keys.port`                                             | JSON key name in the RDS secret for the database port                                                | `port`                     |
| `secret.rds.keys.name`                                             | JSON key name in the RDS secret for the database name                                                | `name`                     |
| `secret.rds.keys.username`                                         | JSON key name in the RDS secret for the database username                                            | `username`                 |
| `secret.rds.keys.password`                                         | JSON key name in the RDS secret for the database password                                            | `password`                 |
| `secret.sshPrivateKey.arn`                                         | AWS secret arn containing the binary content of your SSH private key for use with ssh git operations | `nil`                      |
| `secret.sshKnownHosts.arn`                                         | AWS secret arn containing the binary content of your SSH known hosts for use with ssh git operations | `nil`                      |
| `existingApplicationLoadBalancer.applicationTargetGroupARN`        | Target group ARN for target synchronization with application endpoints                               | `nil`                      |
| `existingApplicationLoadBalancer.adminTargetGroupARN`              | Target group ARN for target synchronization with admin endpoints                                     | `nil`                      |
| `aggregateLogFileRetention.deleteCron`                             | Cron schedule expression for when to delete old aggregate log files if needed                        | `0 1 * * *`                |
| `aggregateLogFileRetention.maxLastModifiedDays`                    | Maximum last modified time of an aggregate log file in days (0 disables deletion)                    | `50`                       |
| `aggregateLogFileRetention.nodeSelector`                           | Node labels for cronjob pod assignment                                                               | `{}`                       |
| `aggregateLogFileRetention.tolerations`                            | Tolerations for cronjob pod assignment                                                               | `[]`                       |
| `aggregateLogFileRetention.affinity`                               | Affinity rules for cronjob pod assignment                                                            | `{}`                       |
| `hpa.enabled`                                                      | Enable Horizontal Pod Autoscaler                                                                     | `false`                    |
| `hpa.minReplicas`                                                  | Minimum number of replicas                                                                           | `2`                        |
| `hpa.maxReplicas`                                                  | Maximum number of replicas                                                                           | `4`                        |
| `hpa.resource.cpu.enabled`                                         | Enable CPU-based autoscaling                                                                         | `true`                     |
| `hpa.resource.cpu.average.threshold`                               | Average CPU threshold for autoscaling                                                                | `50`                       |
| `hpa.resource.memory.enabled`                                      | Enable memory-based autoscaling                                                                      | `false`                    |
| `hpa.resource.memory.average.threshold`                            | Average memory threshold for autoscaling                                                             | `50`                       |
| `global.busybox.imageRegistry`                                     | Container image registry, if not specified the Docker public registry will be used                   | `nil`                      |
| `global.busybox.image`                                             | BusyBox docker image                                                                                 | `busybox`                  |
| `global.busybox.tag`                                               | BusyBox image tag                                                                                    | See `values.yaml`          |
